--Database Compression Script v5.0
--Written by:	Rod Hansen	Sr. PFE Dynamics			Original Author: Michael De Voe, Sr. PFE - Dynamics 
--Last Updated:	Nov 6, 2017


/*************************************************************************************************************************************
*******************************!!!!!!!!! PLEASE READ!!!!!!!!**************************************************************************


Compression is only available on SQL 2008 and later and Enterprise/Devloper Editions.
After compressing your databasse you  will only be able to restore a database backup to Enterprise/Developer Edition of SQL Server
		 
		 		 
This script is presented "AS IS" and has no warrenties expressed or implied.

MAKE A BACK BEFORE DO ANY DATABASE COMPRESSION ACTIVITIES!!!!!

For Dynamics AX you will need to implement DynamicsPef 2.0 to complete the compression process


**************************************************************************************************************************************
*************************************************************************************************************************************/

DECLARE @SQLEDITION VARCHAR(500)
SELECT @SQLEDITION =  CAST(SERVERPROPERTY ('edition') AS nvarchar(40))

IF  NOT (@SQLEDITION  LIKE ('Enterprise%') or @SQLEDITION  LIKE ('Developer%') or @SQLEDITION  LIKE ('Data%')  )
BEGIN
	PRINT 'SQL Server is not Enterprise Editon.  Process Ended....'
	RAISERROR ('Wrong version of SQL for this script',16,1) 
END








DECLARE @COMPRESSION_TYPE VARCHAR(10), @COMPRESS_NOW VARCHAR(1), @MIN_ROWCOUNT INT, @STARTTIME DATETIME, @ENDTIME DATETIME, @TIMEDIFFSECS BIGINT
DECLARE @SUPPRESSSTATUS VARCHAR(1)

SET @COMPRESSION_TYPE = 'ROW'   -- ROW vs. PAGE compression
SET @COMPRESS_NOW = 'N'			--Compress this run, if not then output scripts should be 'Y' to produce scripts to run in another environment
SET @MIN_ROWCOUNT = 1000
SET @SUPPRESSSTATUS = 'N'		--Set to Y if outputing scripts to run on another database


DECLARE @Clustered		smallint;
DECLARE @NonClustered	smallint;
DECLARE @Heap			smallint;

--------------------------------------------------------------------------------------------------------------------------------------
-----Index types you want to consider for Compression---------------------------------------------------------------------------------
SET @Clustered		= 1		--SET THIS TO 1 IF YOU WANT TO RUN THE COMPRESSION ANALYSIS ON CLUSTERED INDEXES 0 IF YOU DO NOT
SET	@NonClustered	= 1		--SET THIS TO 1 IF YOU WANT TO RUN THE COMPRESSION ANALYSIS ON NON-CLUSTERED INDEXES 0 IF YOU DO NOT
SET @Heap			= 1		--SET THIS TO 1 IF YOU WANT TO RUN THE COMPRESSION ANALYSIS ON HEAPS 0 IF YOU DO NOT (Dynamics GP)
-------------------------------------


IF object_id('dbo.Compression_Analysis', 'u') is not null
    DROP TABLE dbo.Compression_Analysis





-------------------------------------------------------------------------------------------------

SET NOCOUNT ON


CREATE TABLE Compression_Analysis
(
Number								int identity(1,1),
ObjectID							int,
Table_Name							nvarchar(250),
Index_Name							nvarchar(250) NULL,
Index_ID							int,
Index_Type							nvarchar(20),
Schema_id							nvarchar(250),
Is_Compressed						nvarchar(4),
Row_Compression_Savings_In_Percent	decimal(38,10),	
Page_Compression_Savings_In_Percent decimal (38,10),
Row_Count							int, 
Percent_Update						decimal(38,10),
Percent_Scan						decimal(38,10),
Script								nvarchar(20),
Comp_Info							nvarchar(100),
Compression_time_secs				bigint,
Page_count							bigint,
Compressed_page_count				bigint,
Size_after_page_count				bigint,
Rebuild								nvarchar(8) DEFAULT 'ONLINE',
UpdateScript						nvarchar(max) NULL
)


PRINT'
Collecting Index Information
 '

IF @Clustered = 1
	BEGIN

		INSERT INTO [Compression_Analysis]
		([ObjectID],[Table_Name],[Index_Name],[Index_ID],[Index_Type],[Schema_id],[Is_Compressed],[Row_Compression_Savings_In_Percent],[Page_Compression_Savings_In_Percent],[Row_Count],[Percent_Update],
		[Percent_Scan],[Script],[Comp_Info],[compression_time_secs],[Page_count], [Compressed_page_count], [Size_after_page_count])

		SELECT	O.object_id, 
				O.name, 
				S.name, 
				S.indid, 
				X.type_desc,
				O.schema_id,
				'NO',
				0,
				0, 
				S.rowcnt, 
				0,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_updates) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_seeks + user_scans + user_lookups) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
				0,
					'N',
					'NONE',
					0,S.dpages * 8,0,0

							FROM  sys.objects O 
		JOIN sys.sysindexes S ON S.id = O.object_id 
		JOIN sys.indexes X ON X.object_id = O.object_id AND X.index_id = S.indid 
		WHERE  X.type_desc = 'CLUSTERED'
		AND S.rowcnt > @MIN_ROWCOUNT
		AND O.type ='U'

		GROUP BY 
		O.object_id, O.name, S.name, S.indid, X.type_desc,O.Schema_id,S.rowcnt, S.dpages

		END;
		


		

IF @NonClustered = 1
	BEGIN

		INSERT INTO [Compression_Analysis]
		([ObjectID],[Table_Name],[Index_Name],[Index_ID],[Index_Type],[Schema_id],[Is_Compressed],[Row_Compression_Savings_In_Percent],[Page_Compression_Savings_In_Percent],[Row_Count],[Percent_Update],
		[Percent_Scan],[Script],[Comp_Info],[Compression_time_secs],[Page_count], [Compressed_page_count], [Size_after_page_count])


			SELECT	O.object_id, 
				O.name, 
				S.name, 
				S.indid, 
				X.type_desc,
				O.schema_id,
				'NO',
				0,
				0, 
				S.rowcnt, 
				0,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_updates) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_seeks + user_scans + user_lookups) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
				0,
					'N',
					'NONE',
					0,S.dpages * 8,0,0

							FROM  sys.objects O 
		JOIN sys.sysindexes S ON S.id = O.object_id 
		JOIN sys.indexes X ON X.object_id = O.object_id AND X.index_id = S.indid 
		WHERE  X.type_desc = 'NONCLUSTERED'
		AND S.rowcnt > @MIN_ROWCOUNT
		AND O.type ='U'

		GROUP BY 
		O.object_id, O.name, S.name, S.indid, X.type_desc,O.Schema_id,S.rowcnt, S.dpages

		END;

IF @Heap = 1
	BEGIN

		INSERT INTO [Compression_Analysis]
		([ObjectID],[Table_Name],[Index_Name],[Index_ID],[Index_Type],[Schema_id],[Is_Compressed],[Row_Compression_Savings_In_Percent],[Page_Compression_Savings_In_Percent],[Row_Count],[Percent_Update],
		[Percent_Scan],[Script],[Comp_Info],[Compression_time_secs],[Page_count], [Compressed_page_count], [Size_after_page_count])

		SELECT	O.object_id, 
				O.name, 
				S.name, 
				S.indid, 
				X.type_desc,
				O.schema_id,
				'NO',
				0,
				0, 
				S.rowcnt, 
				0,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_updates) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
					--CASE
					--	WHEN ( SUM(user_updates + user_seeks + user_scans + user_lookups) = 0 ) THEN NULL
					--	ELSE ROUND(( CAST(SUM(user_seeks + user_scans + user_lookups) AS DECIMAL) / CAST(SUM(user_updates + user_seeks + user_scans + user_lookups) AS DECIMAL) ),2)
					--END,
				0,
					'N',
					'NONE',
					0,S.dpages * 8,0,0

							FROM  sys.objects O 
		JOIN sys.sysindexes S ON S.id = O.object_id 
		JOIN sys.indexes X ON X.object_id = O.object_id AND X.index_id = S.indid 
		WHERE  X.type_desc = 'HEAP'
		AND S.rowcnt > @MIN_ROWCOUNT
		AND O.type ='U'

		GROUP BY 
		O.object_id, O.name, S.name, S.indid, X.type_desc,O.Schema_id,S.rowcnt, S.dpages
		END;

----Remove Compression Tool Tables-------------------------------------------

DELETE FROM Compression_Analysis WHERE Table_Name = 'Compression_Analysis'
DELETE FROM Compression_Analysis WHERE Table_Name = 'Index_Sizes'

-----------------------------------------------------------------------------

----Replace Schema Id with Schema Name---------------------------------------

UPDATE c SET c.Schema_id = ss.name
FROM Compression_Analysis c
JOIN sys.schemas ss ON ss.schema_id = c.Schema_id

-----------------------------------------------------------------------------

PRINT'Checking for Previously Compressed Indexes
 '

CREATE TABLE #Is_Compressed
(
Table_Name			nvarchar(250),
Index_Name			nvarchar(250) NULL,
Compression_Type	int NULL
)

INSERT #Is_Compressed
([Table_Name],[Index_Name],[Compression_Type])

SELECT o.name Table_Name, i.name as Index_Name, p.data_compression  
FROM sys.partitions p
JOIN sys.objects o ON p.object_id = o.object_id
JOIN sys.sysindexes i ON o.object_id = i.id AND p.index_id = i.indid
AND p.data_compression in (1,2)

UPDATE C SET C.Is_Compressed = 'ROW'
FROM Compression_Analysis C
JOIN #Is_Compressed X 
ON CAST(C.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(X.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS 
AND CAST(C.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(X.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS
WHERE X.Compression_Type = 1

UPDATE C SET C.Is_Compressed = 'PAGE'
FROM Compression_Analysis C
JOIN #Is_Compressed X 
ON CAST(C.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(X.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS 
AND CAST(C.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(X.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS
WHERE X.Compression_Type = 2

-------------------------------------------------------------------
---Fix 1 for Dynamics NAV use of special characters in column names 

UPDATE C SET C.Is_Compressed = 'SKIP'
FROM Compression_Analysis C
WHERE C.Table_Name in (	SELECT so.name AS Table_Name
						FROM sys.columns sc
						JOIN sys.objects so ON sc.object_id = so.object_id
						WHERE sc.name LIKE ('%&%')
						AND so.type = 'U'
						OR sc.name LIKE ('%>%')
					 	AND so.type = 'U')

						
--End Fix 1
-------------------------------------------------------------------




-------------------------------------------------------------------
---Fix 2 for Dynmaics CRM and NAV Database that have Indexed columns with TimeStamp data types

UPDATE d SET d.Is_Compressed = 'SKIP'
FROM Compression_Analysis d
JOIN sys.index_columns a on a.index_id = d.Index_ID and a.object_id = d.ObjectID 
JOIN sys.columns b ON a.column_id = b.column_id AND a.object_id = b.object_id 
JOIN sys.types c ON b.system_type_id = c.system_type_id 
WHERE c.name = 'timestamp' 

--End Fix 2
-------------------------------------------------------------------




-------------------------------------------------------------------
---Fix 3 for Dynmaics CRM for tables that have "Text In Row" enabled

UPDATE C SET C.Is_Compressed = 'SKIP'
FROM Compression_Analysis C
WHERE C.Table_Name in (	SELECT name 
						FROM sys.tables
						WHERE text_in_row_limit <> 0)

--End Fix 3
-------------------------------------------------------------------

--ALTER TABLE Compression_Analysis ADD ReBuild nvarchar(8) DEFAULT 'ONLINE' WITH VALUES ;



SET NOCOUNT ON

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[#REBUILD_OPTION]') AND type in (N'U'))
DROP TABLE [#REBUILD_OPTION]


CREATE TABLE #REBUILD_OPTION
(
Object_ID		int,
Table_Name		nvarchar(250),
Column_Name		nvarchar(250),
column_ID		int,
Data_Type		nvarchar(50),
User_Type_ID	int,
Max_Length		int
)


INSERT #REBUILD_OPTION
(Object_ID,
Table_Name,
Column_Name,
column_ID,
Data_Type,
User_Type_ID,
Max_Length)


SELECT 
o.object_id, 
O.name, 
C.name, 
c.column_id, 
T.name, 
c.user_type_id, 
C.max_length
FROM SYS.columns C
JOIN SYS.types	T ON C.user_type_id = T.user_type_id
left JOIN SYS.objects O ON C.object_id = O.object_id
WHERE O.type = 'U'
AND T.name IN ('image','ntext','text','xml')
OR O.type = 'U'
AND C.max_length = -1


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[#INDEX_COLUMNSx]') AND type in (N'U'))
DROP TABLE [#INDEX_COLUMNSx]


CREATE TABLE #INDEX_COLUMNSx
(
Table_Name		nvarchar(250),
Object_ID		int,
Index_Name		nvarchar(250),
Index_Type		nvarchar(20),
Index_ID		int,
Column_ID		int
)

INSERT #INDEX_COLUMNSx
(Table_Name,Object_ID,Index_Name,Index_Type,Index_ID,Column_ID)


SELECT O.name, i.object_id,i.name, i.type_desc, i.index_id, C.column_id
FROM sys.indexes I
JOIN SYS.index_columns C ON C.object_id = I.object_id AND C.index_id = I.index_id
JOIN SYS.objects O ON O.object_id = I.object_id AND O.object_id = C.object_id
WHERE O.type = 'U'


CREATE TABLE #OFFLINE_INDEXES
(
Table_Name	nvarchar(250),
Index_Name	nvarchar(250)
)

INSERT #OFFLINE_INDEXES
(Table_Name,Index_Name)


SELECT R.Table_Name, C.Index_Name
FROM #REBUILD_OPTION R
JOIN #INDEX_COLUMNSx C ON R.Object_ID = C.Object_ID AND R.column_ID = C.Column_ID
UNION
SELECT DISTINCT R.Table_Name, C.Index_Name
FROM #REBUILD_OPTION R
JOIN #INDEX_COLUMNSx C ON R.Object_ID = C.Object_ID
AND C.Index_Type = 'CLUSTERED' 


UPDATE H SET H.ReBuild = 'OFFLINE'
FROM Compression_Analysis H, #OFFLINE_INDEXES O
WHERE CAST(H.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(O.Table_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS
AND  CAST(H.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS = CAST(O.Index_Name as nvarchar(250)) COLLATE SQL_Latin1_General_CP1_CI_AS

--UPDATE Compression_Analysis SET ReBuild = 'ONLINE'
--WHERE Rebuild is NULL

IF @COMPRESSION_TYPE = 'ROW'
BEGIN
UPDATE d SET d.Script = 'R'
FROM Compression_Analysis d
WHERE IS_COMPRESSED <> 'ROW'
END
ELSE
BEGIN
UPDATE d SET d.Script = 'P'
FROM Compression_Analysis d 
WHERE Is_Compressed <> 'PAGE'
END


DROP TABLE #Is_Compressed
DROP TABLE #INDEX_COLUMNSx
DROP TABLE #OFFLINE_INDEXES
DROP TABLE #REBUILD_OPTION


/*********************************************************************************************************************

--REH  Let's compress the indexes now


**********************************************************************************************************************/


/*******PROGRESS***********/

DECLARE @COUNT	nvarchar(5);
SET @COUNT		= (SELECT COUNT(*) FROM Compression_Analysis WHERE Script IN ('R','P'));

/*******PROGRESS***********/

RAISERROR ('ROW Compressing Chosen Indexes.  This could several minutes to several hours depending on the size of the Index',0,1) WITH NOWAIT; 


DECLARE @tablename		sysname;
DECLARE @index_name		sysname;
DECLARE @Schema_id		sysname;
DECLARE @command		varchar(8000);
DECLARE @update			varchar(8000);
DECLARE Compress_ROW	CURSOR FOR

SELECT Table_Name, Index_Name,Schema_id FROM Compression_Analysis
WHERE Script = 'R'
AND Index_Type <> 'HEAP'	


OPEN Compress_ROW

FETCH NEXT FROM Compress_ROW INTO 
	  @tablename, @index_name, @Schema_id

WHILE @@FETCH_STATUS = 0
BEGIN

	SET @TIMEDIFFSECS = 0


BEGIN
	SELECT @command = 'ALTER INDEX ' + '[' + @index_name + ']' + ' ON ' + '[' + @Schema_id + ']' + '.' + '[' + @tablename + ']' + ' REBUILD WITH ( DATA_COMPRESSION = ROW, MAXDOP = 0 )';


	IF @COMPRESS_NOW = 'Y' 
	BEGIN
		SET @STARTTIME = GETDATE()
		EXEC (@command);
		SET @ENDTIME = GETDATE()
		SET @TIMEDIFFSECS = DATEDIFF(SS, @STARTTIME, @ENDTIME)


	END


		SELECT @update = 'UPDATE Compression_Analysis SET Script = ''CR'', Compression_Time_Secs = ' + cast(@timediffsecs as varchar(10)) 
		+ ' , UpdateScript = ''' + @command + ''' WHERE Table_Name = '
		 + '''' + @tablename + '''' + ' AND' + ' Schema_id = ' + '''' + @Schema_id + '''' 
		 + ' AND' + ' Index_Name = ' + '''' + @index_name + '''';
		 EXEC (@update);

END;

	DECLARE @Nmbr1 nvarchar(5);
	SET @Nmbr1 = (SELECT COUNT(*) FROM Compression_Analysis WHERE Script in ('CP', 'CR'));
	DECLARE @msg nvarchar(250);
	SET @msg = 'Compressed ' + @command + ' /' + @Nmbr1 + ' Out Of ' + @COUNT + ' Completed';
	IF @SUPPRESSSTATUS = 'N'  RAISERROR (@msg,0,1) WITH NOWAIT; 

FETCH NEXT FROM Compress_ROW INTO 
	  @tablename, @index_name, @Schema_id
END 
CLOSE Compress_ROW
DEALLOCATE Compress_ROW


RAISERROR ('ROW Compressing HEAPS.  This could several minutes to several hours depending on the size of the Table.',0,1) WITH NOWAIT; 


DECLARE @tablenameB		sysname;
DECLARE @Schema_idB		sysname;
DECLARE @commandB		varchar(8000);
DECLARE @updateB		varchar(8000);
DECLARE Compress_ROWB	CURSOR FOR

SELECT Table_Name, Schema_id FROM Compression_Analysis
WHERE Script = 'R'
AND Index_Type = 'HEAP'	


OPEN Compress_ROWB

FETCH NEXT FROM Compress_ROWB INTO 
	  @tablenameB,@Schema_idB

WHILE @@FETCH_STATUS = 0
BEGIN

SET @TIMEDIFFSECS = 0

BEGIN
	SELECT @commandB = 'ALTER TABLE ' + '[' + @Schema_idB + ']' + '.' + '[' + @tablenameB + ']' + ' REBUILD WITH ( DATA_COMPRESSION = ROW, MAXDOP = 0 )';

	IF @COMPRESS_NOW = 'Y'
	BEGIN
		SET @STARTTIME = GETDATE()
		EXEC (@commandB);
		SET @ENDTIME = GETDATE()
		SET @TIMEDIFFSECS = DATEDIFF(SS, @STARTTIME, @ENDTIME)

	END


			SELECT @updateB = 'UPDATE Compression_Analysis SET Script = ''CR'', Compression_Time_Secs = ' + cast(@timediffsecs as varchar(10)) 
		+ ' , UpdateScript = ''' + @commandB + ''' WHERE Table_Name = '
		 + '''' + @tablenameB + '''' + ' AND' + ' Schema_id = ' + '''' + @Schema_idB + '''' 
		 + ' AND' + ' Index_Type = ''HEAP''';
		 EXEC (@updateB);
END;

	DECLARE @Nmbr2 nvarchar(5);
	SET @Nmbr2 = (SELECT COUNT(*) FROM Compression_Analysis WHERE Script in ('CP', 'CR'));
	DECLARE @msg2 nvarchar(250);
	SET @msg2 = 'Compressed ' + @commandB + ' /' + @Nmbr2 + ' Out Of ' + @COUNT + ' Completed';
	IF @SUPPRESSSTATUS = 'N' RAISERROR (@msg2,0,1) WITH NOWAIT; 

FETCH NEXT FROM Compress_ROWB INTO 
	  @tablenameB,@Schema_idB
END 
CLOSE Compress_ROWB
DEALLOCATE Compress_ROWB


RAISERROR ('PAGE Compressing Chosen Indexes.  This could several minutes to several hours depending on the size of the Index.',0,1) WITH NOWAIT;

DECLARE @tablename2		sysname;
DECLARE @index_name2	sysname;
DECLARE @Schema_id2		sysname;
DECLARE @command2		varchar(8000);
DECLARE @update2		varchar(8000);
DECLARE Compress_PAGE	CURSOR FOR

SELECT Table_Name, Index_Name, Schema_id FROM Compression_Analysis
WHERE Script = 'P'
AND Index_Type <> 'HEAP'	


OPEN Compress_PAGE

FETCH NEXT FROM Compress_PAGE INTO 
	  @tablename2, @index_name2, @Schema_id2

WHILE @@FETCH_STATUS = 0
BEGIN

SET @TIMEDIFFSECS = 0

BEGIN
	SELECT @command2 = 'ALTER INDEX ' + '[' + @index_name2 + ']' + ' ON ' + '[' + @Schema_id2 + ']' + '.' + '[' + @tablename2 + ']' + ' REBUILD WITH ( DATA_COMPRESSION = PAGE, MAXDOP = 0 )';

	IF @COMPRESS_NOW = 'Y'
	BEGIN

		SET @STARTTIME = GETDATE()
		EXEC (@command2);
		SET @ENDTIME = GETDATE()
		SET @TIMEDIFFSECS = DATEDIFF(SS, @STARTTIME, @ENDTIME)

	END

			SELECT @update2 = 'UPDATE Compression_Analysis SET Script = ''CR'', Compression_Time_Secs = ' + cast(@timediffsecs as varchar(10)) 
		+ ' , UpdateScript = ''' + @command2 + ''' WHERE Table_Name = '
		 + '''' + @tablename2 + '''' + ' AND' + ' Schema_id = ' + '''' + @Schema_id2 + '''' 
		 + ' AND' + ' Index_Name = ' + '''' + @index_name2 + '''';
		 EXEC (@update2);


END;

	DECLARE @Nmbr3 nvarchar(5);
	SET @Nmbr3 = (SELECT COUNT(*) FROM Compression_Analysis WHERE Script in ('CP', 'CR'));
	DECLARE @msg3 nvarchar(250);
	SET @msg3 = 'Compressed ' + @command2 + ' /' + @Nmbr3 + ' Out Of ' + @COUNT + ' Completed';
	IF @SUPPRESSSTATUS = 'N' RAISERROR (@msg3,0,1) WITH NOWAIT; 

FETCH NEXT FROM Compress_PAGE INTO 
	  @tablename2, @index_name2, @Schema_id2
END 
CLOSE Compress_PAGE
DEALLOCATE Compress_PAGE


RAISERROR ('PAGE Compressing HEAPS.  This could several minutes to several hours depending on the size of the Table.',0,1) WITH NOWAIT;



DECLARE @tablenameC		sysname;
DECLARE @schema_idC		sysname;
DECLARE @commandC		varchar(8000);
DECLARE @updateC		varchar(8000);
DECLARE Compress_PAGEC	CURSOR FOR

SELECT Table_Name, Schema_id FROM Compression_Analysis
WHERE Script = 'P'
AND Index_Type = 'HEAP'	


OPEN Compress_PAGEC

FETCH NEXT FROM Compress_PAGEC INTO 
	  @tablenameC, @schema_idC

WHILE @@FETCH_STATUS = 0
BEGIN

SET @TIMEDIFFSECS = 0

BEGIN
	SELECT @commandC = 'ALTER TABLE ' + '[' + @Schema_idC + ']' + '.' + '[' + @tablenameC + ']' + ' REBUILD WITH ( DATA_COMPRESSION = PAGE, MAXDOP = 0 )';

	IF @COMPRESS_NOW = 'Y'
	BEGIN

		SET @STARTTIME = GETDATE()
		EXEC (@commandC);
		SET @ENDTIME = GETDATE()
		SET @TIMEDIFFSECS = DATEDIFF(SS, @STARTTIME, @ENDTIME)

	END


		SELECT @updateC = 'UPDATE Compression_Analysis SET Script = ''CR'', Compression_Time_Secs = ' + cast(@timediffsecs as varchar(10)) 
		+ ' , UpdateScript = ''' + @commandC + ''' WHERE Table_Name = '
		 + '''' + @tablenameC + '''' + ' AND' + ' Schema_id = ' + '''' + @schema_idC + '''' 
		 + ' AND' + ' Index_Type = ''HEAP''';
		 EXEC (@updateC);

END;

	DECLARE @Nmbr4 nvarchar(5);
	SET @Nmbr4 = (SELECT COUNT(*) FROM Compression_Analysis WHERE Script in ('CP', 'CR'));
	DECLARE @msg4 nvarchar(250);
	SET @msg4 = 'Executed ' + @commandC + ' /' + @Nmbr4 + ' Out Of ' + @COUNT + ' Completed';
	IF @SUPPRESSSTATUS = 'N' RAISERROR (@msg4,0,1) WITH NOWAIT; 

FETCH NEXT FROM Compress_PAGEC INTO 
	  @tablenameC, @schema_idC
END 
CLOSE Compress_PAGEC
DEALLOCATE Compress_PAGEC

RAISERROR ('Calculating New Index Sizes for "Before" and "After" Comparison.',0,1) WITH NOWAIT;
 
UPDATE x SET x.Size_after_page_count = (y.dpages*8)
FROM Compression_Analysis x
JOIN sys.sysindexes y on x.ObjectId = y.id and x.Index_Id = y.indid


UPDATE x SET x.Comp_Info = 
	(CASE
	WHEN y.data_compression = 0 THEN 'NONE'
	WHEN y.data_compression = 1 THEN 'ROW'
	WHEN y.data_compression = 2 THEN 'PAGE'
	ELSE 'ERR'
	END)	
FROM Compression_Analysis x
JOIN sys.partitions y on y.object_Id = x.ObjectId and y.index_id = x.Index_Id

UPDATE Compression_Analysis
SET Is_Compressed = 'Yes'
WHERE Script IN ('CP','CR') 

DECLARE @TOTALTIME DEC(29,3), @TOTALSPACESAVED BIGINT , @TEXTMSG VARCHAR(8000)

SELECT @TOTALTIME = SUM( Compression_time_secs )/60 FROM Compression_Analysis
SELECT  @TOTALSPACESAVED = (SUM(Size_after_page_count) * 8 /1024 )   -  (SUM(Page_count) * 8 /1024 ) FROM Compression_Analysis


SET @TEXTMSG = 'Total time to compress was ' + cast(@TOTALTIME AS VARCHAR(20)) + ' minutes ' + char(10) 
+ 'Total space saved was ' + cast(@TOTALSPACESAVED AS VARCHAR(20)) + ' MB '

PRINT ''
PRINT @TEXTMSG
PRINT ''
PRINT ''




SELECT UPDATESCRIPT, *
 FROM Compression_Analysis 
 WHERE UpdateScript IS NOT NULL 
 ORDER BY Compression_time_secs DESC






