--Database Compression Script v5.0
--Written by:	Rod Hansen	Sr. PFE Dynamics			Original Author: Michael De Voe, Sr. PFE - Dynamics 
--Last Updated:	Nov 5, 2017



/*************************************************************************************************************************************
*******************************!!!!!!!!! PLEASE READ!!!!!!!!**************************************************************************


NOTE: DYNAMICSPERF 2.0 MUST BE INSTALLED AND AUTOEXPORT2012_DIRECT CLASS RUN BEFORE EXECUTING THE REST OF THIS SCRIPT



Compression is only available on SQL 2008 and later and Enterprise/Devloper Editions.
After compressing your databasse you  will only be able to restore a database backup to Enterprise/Developer Edition of SQL Server
		 
		 		 
This script is presented "AS IS" and has no warrenties expressed or implied.

MAKE A BACK BEFORE DO ANY DATABASE COMPRESSION ACTIVITIES!!!!!


**************************************************************************************************************************************
*************************************************************************************************************************************/



/********  RUN THIS SCRIPT IN YOUR AX DATABASE    ********

NOTE: If DynamicsPerf is on a remote server, you will have
		to setup a Lineked Server and modify these views

************************************************************/


if object_id('dbo.AX_INDEX_DETAIL', 'V') is not null
    DROP VIEW dbo.AX_INDEX_DETAIL


if object_id('dbo.AX_TABLE_DETAIL', 'V') is not null
 DROP VIEW dbo.AX_TABLE_DETAIL

GO

CREATE VIEW AX_INDEX_DETAIL
AS 
SELECT * FROM DynamicsPerf.DBO.AX_INDEX_DETAIL

GO
CREATE VIEW AX_TABLE_DETAIL
AS
SELECT * FROM DynamicsPerf.DBO.AX_TABLE_DETAIL

GO






--REH Run the following query to start the seed for the #SQLStorage_Temp table


PRINT
'
Updating Dynamics AX SQLStorage Table with Compression Information
'

if object_id('tempdb..#SQLStorage_Temp', 'u') is not null
    drop table #SQLStorage_Temp

if object_id('dbo.Compression_ConfigNC', 'u') is not null
    drop table dbo.Compression_ConfigNC





Create Table #SQLStorage_Temp
(
ID INT,
OBJECTTYPE INT,
TABLEID INT,
INDEXID INT,
OVERRIDE INT,
PARM NVARCHAR(25),
VALUE NVARCHAR(255),
RECVERSION INT,
RECID BIGINT IDENTITY(56371455760,1)
)

CREATE TABLE Compression_ConfigNC
(
Table_Name NVARCHAR(255),
Index_Name NVARCHAR(255) NULL,
Type NVARCHAR(20),
Compression NVARCHAR(5),
AX_Table_Id int
)

INSERT Compression_ConfigNC
(Table_Name,Index_Name,Type,Compression)

SELECT so.name AS Table_Name, si.name AS Index_Name, si.type_desc as Type, sp.data_compression_desc 
FROM sys.partitions sp
JOIN sys.indexes si ON si.index_id = sp.index_id AND si.object_id = sp.object_id
JOIN sys.objects so ON so.object_id = si.object_id
WHERE sp.data_compression_desc <> 'NONE'

UPDATE C SET C.AX_Table_Id = TP.TABLE_ID
FROM Compression_ConfigNC C
JOIN AX_TABLE_DETAIL TP ON TP.TABLE_NAME = C.Table_Name 


---Index Pass 1 PARM Record
INSERT #SQLStorage_Temp
(ID ,OBJECTTYPE,TABLEID,INDEXID,OVERRIDE,PARM,VALUE,RECVERSION)

----------------------------------------------------------------------------
SELECT 
0,
1,
CC.AX_Table_Id,
IP.INDEX_ID,  
0,
'COMPRESSION',
CASE
	WHEN CC.Compression = 'PAGE' THEN '1'
	WHEN CC.Compression = 'ROW' THEN '2'
	END,
1  
FROM AX_INDEX_DETAIL IP --ON TP.TABLENAME = IP.TABLENAME 
JOIN Compression_ConfigNC CC ON IP.TABLE_NAME = CC.Table_Name AND IP.INDEX_NAME = CC.Index_Name  



----------------------------------------------------------------------------------

--Index Pass 2 VALUE Record
INSERT #SQLStorage_Temp
(ID ,OBJECTTYPE,TABLEID,INDEXID,OVERRIDE,PARM,VALUE,RECVERSION)


SELECT 
1,
1,
CC.AX_Table_Id,
IP.INDEX_ID, 
0,
'',
CASE
	WHEN CC.Compression = 'PAGE' THEN 'WITH (DATA_COMPRESSION = PAGE )'
	WHEN CC.Compression = 'ROW' THEN 'WITH (DATA_COMPRESSION = ROW )'
	END,
1  
FROM Compression_ConfigNC CC  
JOIN AX_INDEX_DETAIL IP ON CC.Table_Name = IP.TABLE_NAME AND IP.INDEX_NAME = CC.Index_Name


--REH Delete compression overrides to prevent duplicates

DELETE SS FROM SQLSTORAGE SS INNER JOIN #SQLStorage_Temp ST
ON SS.ID = ST.ID AND SS.TABLEID = ST.TABLEID AND SS.INDEXID = ST.INDEXID 
WHERE SS.PARM LIKE 'COMPRESSION%'

DELETE SS FROM SQLSTORAGE SS INNER JOIN #SQLStorage_Temp ST
ON SS.ID = ST.ID AND SS.TABLEID = ST.TABLEID AND SS.INDEXID = ST.INDEXID 
WHERE SS.VALUE LIKE 'WITH (DATA_COMPRESSION%'


--Insert #SQLStorage_Temp Records into SQLStorage
INSERT SQLSTORAGE	
([ID],[OBJECTTYPE],[TABLEID],[INDEXID],[OVERRIDE],[PARM],[VALUE],[RECVERSION],[RECID])

SELECT [ID],[OBJECTTYPE],[TABLEID],[INDEXID],[OVERRIDE],[PARM],[VALUE],[RECVERSION],[RECID] FROM #SQLStorage_Temp


--Create or update the SYSTEMSEQUENCES record for the SQLStorage Table
IF (SELECT COUNT(*) FROM SYSTEMSEQUENCES WHERE TABID = '65515') > 0
	BEGIN
	UPDATE SYSTEMSEQUENCES SET NEXTVAL = (SELECT (MAX(RECID)+1) FROM #SQLStorage_Temp)
	WHERE TABID = '65515' 
	END;
	
IF (SELECT COUNT(*) FROM SYSTEMSEQUENCES WHERE TABID = '65515') < 1
	BEGIN
	INSERT SYSTEMSEQUENCES
	(ID,NEXTVAL,MINVAL,MAXVAL,CYCLE,NAME,TABID,DATAAREAID,RECVERSION,RECID)
	VALUES
	(-1,(SELECT (MAX(RECID)+1) FROM #SQLStorage_Temp),1,9223372036854775807,0,'SEQNO','65515','dat',1,-1)
	END;


DROP TABLE #SQLStorage_Temp
DROP TABLE Compression_ConfigNC

if object_id('dbo.AX_INDEX_DETAIL', 'V') is not null
    DROP VIEW dbo.AX_INDEX_DETAIL


if object_id('dbo.AX_TABLE_DETAIL', 'V') is not null
DROP VIEW dbo.AX_TABLE_DETAIL


PRINT
'
Completed
'


